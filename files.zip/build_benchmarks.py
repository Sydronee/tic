#!/usr/bin/env python3
"""
build_benchmarks.py
--------------------
Builds the `benchmarks` materialized table in transparency.duckdb by joining
all enrichment tables (provider geo, code descriptions) to the rate fact table.

What it produces
----------------
  transparency.duckdb::benchmarks  — denormalized fact table, one row per rate,
      enriched with:
        • canonical code description (enrichment > MRF fallback)
        • provider name, specialty (taxonomy), city/state/ZIP (NPPES)
        • dominant county FIPS + county name (ZIP→county crosswalk)
        • payer / plan metadata

  transparency.duckdb::benchmarks_code_stats   — per-(code,code_type) summary:
        n_rates, n_providers, n_payers, p10/p25/median/p75/p90, min, max, avg
        Useful for "what does this CPT cost across all providers?"

  transparency.duckdb::benchmarks_geo_stats    — per-(code,state,county) summary:
        median, avg, min, max — for choropleth maps

  transparency.duckdb::benchmarks_payer_stats  — per-(code,payer) summary:
        for "UHC vs Aetna" comparisons

Usage
-----
    python build_benchmarks.py [--enrichment-db enrichment.duckdb]
                               [--transparency-db transparency.duckdb]
                               [--drop-first]        # rebuild from scratch
                               [--stats-only]        # skip benchmarks rebuild, redo stats only

Performance notes
-----------------
  2.4M rows × 3-way enrichment join typically takes 20-60s on a laptop.
  The result is ~400-600 MB on disk after ZSTD checkpoint.
  All three stat views are cheap derived aggregations (<5s each).
"""

import argparse
import time
from pathlib import Path

import duckdb


def build(
    transparency_db: str,
    enrichment_db: str,
    drop_first: bool,
    stats_only: bool,
) -> None:
    t_total = time.time()

    if not Path(transparency_db).exists():
        raise FileNotFoundError(f"transparency.duckdb not found: {transparency_db}")
    if not Path(enrichment_db).exists():
        raise FileNotFoundError(f"enrichment.duckdb not found: {enrichment_db}")

    print(f"Connecting to {transparency_db} ...")
    con = duckdb.connect(transparency_db)

    print(f"Attaching {enrichment_db} as ref ...")
    con.execute(f"ATTACH '{enrichment_db}' AS ref (READ_ONLY)")

    # ------------------------------------------------------------------ #
    # Validate enrichment tables exist                                     #
    # ------------------------------------------------------------------ #
    for tbl in ("ref.code_descriptions", "ref.nppes", "ref.zip_county"):
        n = con.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        print(f"  {tbl}: {n:,} rows")

    # ------------------------------------------------------------------ #
    # BENCHMARKS — main denormalized table                                 #
    # ------------------------------------------------------------------ #
    if not stats_only:
        if drop_first:
            print("\nDropping existing benchmarks table ...")
            con.execute("DROP TABLE IF EXISTS benchmarks")

        print("\nBuilding benchmarks table ...")
        t0 = time.time()

        con.execute("""
            CREATE TABLE IF NOT EXISTS benchmarks AS

            WITH

            -- ── RC code normalisation ─────────────────────────────────────
            -- MRF revenue codes are stored with inconsistent padding:
            -- '771      ' (trailing spaces), '230' (3-digit), '0250' (4-digit).
            -- Normalise to 4-digit zero-padded for the description join.
            rates_norm AS (
                SELECT
                    r.payer_id,
                    r.code_id,
                    r.negotiation_arrangement,
                    r.billing_class,
                    r.setting,
                    r.negotiated_type,
                    r.negotiated_rate,
                    r.service_code,
                    r.billing_code_modifier,
                    r.expiration_date,
                    r.provider_reference_ids,
                    r.source_file,
                    r.ingested_at
                FROM negotiated_rates r
                -- Only keep fee-for-service negotiated rates; skip capitation,
                -- per diem, and percent-of-billed to keep comparisons apples-to-apples.
                -- Remove this filter if you need all rate types.
                WHERE r.negotiated_type IN ('negotiated', 'fee schedule', 'derived')
                  AND r.negotiated_rate > 0
                  AND r.negotiated_rate < 10_000_000   -- sanity ceiling
            ),

            -- ── Explode provider_reference_ids array → one row per NPI ────
            -- negotiated_rates.provider_reference_ids is a BIGINT[] that links
            -- to providers.provider_reference_id. A single rate can cover many
            -- providers (e.g. a whole network). We unnest so each rate×provider
            -- pair becomes its own row, enabling per-provider benchmarking.
            --
            -- Rates with provider_reference_ids = [0] are network-wide rates
            -- with no specific NPI. We keep them (npi will be NULL).
            rates_exploded AS (
                SELECT
                    rn.*,
                    UNNEST(rn.provider_reference_ids) AS provider_reference_id
                FROM rates_norm rn
            ),

            -- ── Provider join ──────────────────────────────────────────────
            -- Join to providers on provider_reference_id to get NPI,
            -- facility name, TIN, and network name.
            rates_with_provider AS (
                SELECT
                    re.*,
                    p.npi,
                    p.tin_type,
                    p.tin_value,
                    p.facility_name,
                    p.network_name
                FROM rates_exploded re
                LEFT JOIN providers p
                    ON p.provider_reference_id = re.provider_reference_id
                   AND re.provider_reference_id != 0   -- 0 = network-wide, no provider
            ),

            -- ── NPPES enrichment ───────────────────────────────────────────
            rates_with_nppes AS (
                SELECT
                    rwp.*,
                    n.entity_type          AS provider_entity_type,
                    n.provider_name        AS provider_name_nppes,
                    n.city                 AS provider_city,
                    n.state                AS provider_state,
                    n.zip5                 AS provider_zip5,
                    n.taxonomy_code        AS provider_taxonomy_code
                FROM rates_with_provider rwp
                LEFT JOIN ref.nppes n
                    ON n.npi = rwp.npi
            ),

            -- ── ZIP → dominant county ──────────────────────────────────────
            -- zip_county is many-to-many (ZIPs span counties).
            -- We pick the county with the highest tot_ratio per ZIP,
            -- giving a clean 1-to-1 for choropleth mapping.
            dominant_county AS (
                SELECT DISTINCT ON (zip5)
                    zip5,
                    fips          AS county_fips,
                    county_name,
                    state_abbr    AS county_state
                FROM ref.zip_county
                WHERE zip5 IS NOT NULL
                ORDER BY zip5, tot_ratio DESC
            ),

            rates_with_geo AS (
                SELECT
                    rwn.*,
                    dc.county_fips,
                    dc.county_name,
                    dc.county_state
                FROM rates_with_nppes rwn
                LEFT JOIN dominant_county dc
                    ON dc.zip5 = rwn.provider_zip5
            ),

            -- ── Code description enrichment ────────────────────────────────
            -- RC codes: normalise to 4-digit before joining.
            -- Prefer enrichment description; fall back to MRF description.
            rates_with_codes AS (
                SELECT
                    rwg.*,
                    bc.billing_code,
                    bc.billing_code_type,
                    bc.billing_code_type_version,
                    bc.negotiation_arrangement       AS code_negotiation_arrangement,
                    COALESCE(
                        cd.description,
                        bc.description,
                        bc.name
                    )                                AS code_description,
                    -- Flag whether we got a canonical description
                    (cd.description IS NOT NULL)     AS has_canonical_description,
                    -- RC normalised code for display
                    CASE
                        WHEN bc.billing_code_type = 'RC'
                        THEN LPAD(TRIM(bc.billing_code), 4, '0')
                        ELSE bc.billing_code
                    END                              AS billing_code_display
                FROM rates_with_geo rwg
                JOIN billing_codes bc
                    ON bc.code_id = rwg.code_id
                LEFT JOIN ref.code_descriptions cd
                    ON  cd.billing_code_type =  bc.billing_code_type
                    AND cd.billing_code      =  CASE
                        WHEN bc.billing_code_type = 'RC'
                        THEN LPAD(TRIM(bc.billing_code), 4, '0')
                        ELSE bc.billing_code
                    END
            )

            -- ── Final SELECT ───────────────────────────────────────────────
            SELECT
                -- Rate identity
                rwc.payer_id,
                rwc.code_id,

                -- Code dimensions
                rwc.billing_code_display            AS billing_code,
                rwc.billing_code_type,
                rwc.billing_code_type_version,
                rwc.code_description,
                rwc.has_canonical_description,
                rwc.code_negotiation_arrangement,

                -- Rate facts
                rwc.negotiation_arrangement,
                rwc.billing_class,
                rwc.setting,
                rwc.negotiated_type,
                rwc.negotiated_rate,
                rwc.service_code,
                rwc.billing_code_modifier,
                rwc.expiration_date,
                rwc.ingested_at,

                -- Payer dimensions
                py.reporting_entity_name            AS payer_name,
                py.reporting_entity_type,
                py.plan_name,
                py.plan_market_type,
                py.last_updated_on                  AS rate_file_date,

                -- Provider dimensions (from transparency providers table)
                rwc.provider_reference_id,
                rwc.npi,
                COALESCE(rwc.facility_name,
                         rwc.provider_name_nppes)   AS provider_name,
                rwc.tin_type,
                rwc.tin_value,
                rwc.network_name,

                -- Provider geo (from NPPES)
                rwc.provider_entity_type,
                rwc.provider_name_nppes,
                rwc.provider_city,
                rwc.provider_state,
                rwc.provider_zip5,
                rwc.provider_taxonomy_code,

                -- County geo (from ZIP→county crosswalk)
                rwc.county_fips,
                rwc.county_name,
                rwc.county_state,

                -- Source tracking
                rwc.source_file

            FROM rates_with_codes rwc
            JOIN payers py ON py.payer_id = rwc.payer_id
        """)

        n_benchmarks = con.execute("SELECT COUNT(*) FROM benchmarks").fetchone()[0]
        print(f"  benchmarks: {n_benchmarks:,} rows  ({time.time()-t0:.1f}s)")

        # Indexes on the hot query dimensions
        print("Building indexes on benchmarks ...")
        t0 = time.time()
        for idx_sql in [
            "CREATE INDEX IF NOT EXISTS idx_bm_code      ON benchmarks(billing_code, billing_code_type)",
            "CREATE INDEX IF NOT EXISTS idx_bm_payer     ON benchmarks(payer_name)",
            "CREATE INDEX IF NOT EXISTS idx_bm_state     ON benchmarks(provider_state)",
            "CREATE INDEX IF NOT EXISTS idx_bm_county    ON benchmarks(county_fips)",
            "CREATE INDEX IF NOT EXISTS idx_bm_npi       ON benchmarks(npi)",
            "CREATE INDEX IF NOT EXISTS idx_bm_rate      ON benchmarks(negotiated_rate)",
            "CREATE INDEX IF NOT EXISTS idx_bm_code_type ON benchmarks(billing_code_type)",
        ]:
            con.execute(idx_sql)
        print(f"  Done ({time.time()-t0:.1f}s)")

    # ------------------------------------------------------------------ #
    # STAT TABLES — aggregated views materialized as tables                #
    # (Tables, not views, so DuckDB WASM can query them without ATTACH)   #
    # ------------------------------------------------------------------ #

    # ── Per-code stats ────────────────────────────────────────────────────
    print("\nBuilding benchmarks_code_stats ...")
    t0 = time.time()
    con.execute("DROP TABLE IF EXISTS benchmarks_code_stats")
    con.execute("""
        CREATE TABLE benchmarks_code_stats AS
        SELECT
            billing_code,
            billing_code_type,
            MAX(code_description)                            AS code_description,
            BOOL_OR(has_canonical_description)               AS has_canonical_description,
            COUNT(*)                                         AS n_rates,
            COUNT(DISTINCT npi)                              AS n_providers,
            COUNT(DISTINCT payer_name)                       AS n_payers,
            COUNT(DISTINCT county_fips)                      AS n_counties,
            ROUND(MIN(negotiated_rate),    2)                AS rate_min,
            ROUND(PERCENTILE_CONT(0.10) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p10,
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p25,
            ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_median,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p75,
            ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p90,
            ROUND(MAX(negotiated_rate),    2)                AS rate_max,
            ROUND(AVG(negotiated_rate),    2)                AS rate_avg,
            ROUND(STDDEV(negotiated_rate), 2)                AS rate_stddev
        FROM benchmarks
        GROUP BY billing_code, billing_code_type
    """)
    n = con.execute("SELECT COUNT(*) FROM benchmarks_code_stats").fetchone()[0]
    print(f"  benchmarks_code_stats: {n:,} rows  ({time.time()-t0:.1f}s)")

    # ── Per-code × geo stats ──────────────────────────────────────────────
    print("Building benchmarks_geo_stats ...")
    t0 = time.time()
    con.execute("DROP TABLE IF EXISTS benchmarks_geo_stats")
    con.execute("""
        CREATE TABLE benchmarks_geo_stats AS
        SELECT
            billing_code,
            billing_code_type,
            MAX(code_description)                            AS code_description,
            provider_state,
            county_fips,
            MAX(county_name)                                 AS county_name,
            COUNT(*)                                         AS n_rates,
            COUNT(DISTINCT npi)                              AS n_providers,
            COUNT(DISTINCT payer_name)                       AS n_payers,
            ROUND(MIN(negotiated_rate),    2)                AS rate_min,
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p25,
            ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_median,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p75,
            ROUND(MAX(negotiated_rate),    2)                AS rate_max,
            ROUND(AVG(negotiated_rate),    2)                AS rate_avg
        FROM benchmarks
        WHERE provider_state IS NOT NULL
        GROUP BY billing_code, billing_code_type, provider_state, county_fips
    """)
    n = con.execute("SELECT COUNT(*) FROM benchmarks_geo_stats").fetchone()[0]
    print(f"  benchmarks_geo_stats:  {n:,} rows  ({time.time()-t0:.1f}s)")

    # ── Per-code × payer stats ────────────────────────────────────────────
    print("Building benchmarks_payer_stats ...")
    t0 = time.time()
    con.execute("DROP TABLE IF EXISTS benchmarks_payer_stats")
    con.execute("""
        CREATE TABLE benchmarks_payer_stats AS
        SELECT
            billing_code,
            billing_code_type,
            MAX(code_description)                            AS code_description,
            payer_name,
            MAX(plan_market_type)                            AS plan_market_type,
            COUNT(*)                                         AS n_rates,
            COUNT(DISTINCT npi)                              AS n_providers,
            COUNT(DISTINCT provider_state)                   AS n_states,
            ROUND(MIN(negotiated_rate),    2)                AS rate_min,
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p25,
            ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_median,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_p75,
            ROUND(MAX(negotiated_rate),    2)                AS rate_max,
            ROUND(AVG(negotiated_rate),    2)                AS rate_avg
        FROM benchmarks
        GROUP BY billing_code, billing_code_type, payer_name
    """)
    n = con.execute("SELECT COUNT(*) FROM benchmarks_payer_stats").fetchone()[0]
    print(f"  benchmarks_payer_stats: {n:,} rows  ({time.time()-t0:.1f}s)")

    # ── Per-code × provider stats (for provider-level comparison) ─────────
    print("Building benchmarks_provider_stats ...")
    t0 = time.time()
    con.execute("DROP TABLE IF EXISTS benchmarks_provider_stats")
    con.execute("""
        CREATE TABLE benchmarks_provider_stats AS
        SELECT
            billing_code,
            billing_code_type,
            MAX(code_description)                            AS code_description,
            npi,
            MAX(provider_name)                               AS provider_name,
            MAX(provider_city)                               AS provider_city,
            MAX(provider_state)                              AS provider_state,
            MAX(provider_zip5)                               AS provider_zip5,
            MAX(county_fips)                                 AS county_fips,
            MAX(county_name)                                 AS county_name,
            MAX(provider_taxonomy_code)                      AS taxonomy_code,
            COUNT(*)                                         AS n_rates,
            COUNT(DISTINCT payer_name)                       AS n_payers,
            ROUND(MIN(negotiated_rate),    2)                AS rate_min,
            ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP
                  (ORDER BY negotiated_rate), 2)             AS rate_median,
            ROUND(MAX(negotiated_rate),    2)                AS rate_max,
            ROUND(AVG(negotiated_rate),    2)                AS rate_avg
        FROM benchmarks
        WHERE npi IS NOT NULL
        GROUP BY billing_code, billing_code_type, npi
    """)
    n = con.execute("SELECT COUNT(*) FROM benchmarks_provider_stats").fetchone()[0]
    print(f"  benchmarks_provider_stats: {n:,} rows  ({time.time()-t0:.1f}s)")

    # ── Sanity checks ─────────────────────────────────────────────────────
    print("\nSanity checks:")
    # Description coverage
    cov = con.execute("""
        SELECT
            billing_code_type,
            COUNT(*)                                              AS n_rates,
            ROUND(100.0 * SUM(has_canonical_description::INT)
                / COUNT(*), 1)                                   AS canonical_pct,
            COUNT(DISTINCT billing_code)                          AS distinct_codes
        FROM benchmarks
        GROUP BY billing_code_type
        ORDER BY n_rates DESC
    """).df()
    print("\n  Description coverage by code type:")
    print(cov.to_string(index=False))

    # NPPES hit rate
    nppes_hit = con.execute("""
        SELECT
            COUNT(*)                                             AS total_rates,
            COUNT(CASE WHEN npi IS NOT NULL THEN 1 END)         AS has_npi,
            COUNT(CASE WHEN provider_state IS NOT NULL THEN 1 END) AS has_geo,
            COUNT(CASE WHEN county_fips IS NOT NULL THEN 1 END)    AS has_county,
            ROUND(100.0 * COUNT(CASE WHEN provider_state IS NOT NULL THEN 1 END)
                / COUNT(*), 1)                                   AS geo_pct
        FROM benchmarks
    """).fetchone()
    print(f"\n  Total rows      : {nppes_hit[0]:,}")
    print(f"  Has NPI         : {nppes_hit[1]:,}")
    print(f"  Has state (geo) : {nppes_hit[2]:,}  ({nppes_hit[4]}%)")
    print(f"  Has county      : {nppes_hit[3]:,}")

    # Top 10 codes by rate count
    top10 = con.execute("""
        SELECT billing_code, billing_code_type, code_description, n_rates, rate_median
        FROM benchmarks_code_stats
        ORDER BY n_rates DESC LIMIT 10
    """).df()
    print("\n  Top 10 codes by rate count:")
    print(top10.to_string(index=False))

    # ── Checkpoint ────────────────────────────────────────────────────────
    print("\nCheckpointing (ZSTD) ...")
    con.execute("PRAGMA force_compression='zstd'")
    con.execute("CHECKPOINT")
    con.close()

    print(f"\nAll done in {time.time()-t_total:.1f}s total")
    print("New tables in transparency.duckdb:")
    print("  benchmarks                  — full denormalized rate×provider×geo×code")
    print("  benchmarks_code_stats       — p10/p25/median/p75/p90 per code")
    print("  benchmarks_geo_stats        — median/avg per code×state×county")
    print("  benchmarks_payer_stats      — median/avg per code×payer")
    print("  benchmarks_provider_stats   — median/avg per code×NPI")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--transparency-db", default="transparency.duckdb")
    ap.add_argument("--enrichment-db",   default="enrichment.duckdb")
    ap.add_argument("--drop-first",      action="store_true",
                    help="DROP TABLE benchmarks before rebuilding (use when re-running)")
    ap.add_argument("--stats-only",      action="store_true",
                    help="Skip benchmarks rebuild; only recompute stat tables")
    args = ap.parse_args()

    build(
        transparency_db=args.transparency_db,
        enrichment_db=args.enrichment_db,
        drop_first=args.drop_first,
        stats_only=args.stats_only,
    )


if __name__ == "__main__":
    main()

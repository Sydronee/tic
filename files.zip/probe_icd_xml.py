#!/usr/bin/env python3
"""
probe_icd_xml.py
----------------
Probes the first pcsTable in icd10pcs_tables_2027.xml and prints the
exact tag names, attribute names, and child structure so the parser
can be corrected.

Run from TiC/:
    python probe_icd_xml.py reference_data/icd10pcs_tables_2027.xml
"""
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

def probe(path: str):
    print(f"Parsing {path} ...")
    tree = ET.parse(path)
    root = tree.getroot()

    print(f"\nRoot tag       : <{root.tag}>")
    print(f"Root attribs   : {root.attrib}")
    print(f"Direct children: {[(c.tag, c.attrib) for c in root][:20]}")

    # Find first pcsTable (try both cases)
    table = root.find("pcsTable") or root.find("PCSTable")
    if table is None:
        print("\nERROR: No <pcsTable> or <PCSTable> found as direct child of root")
        print("All direct child tags:", [c.tag for c in root])
        return

    print(f"\n--- First <{table.tag}> ---")
    print(f"  pcsTable attribs: {table.attrib}")
    print(f"  Direct children of pcsTable:")
    for i, child in enumerate(table):
        print(f"    [{i}] <{child.tag}> attribs={child.attrib}")
        for j, grandchild in enumerate(child):
            print(f"          [{j}] <{grandchild.tag}> attribs={grandchild.attrib} text={repr(grandchild.text)}")
            for k, ggc in enumerate(grandchild):
                print(f"                [{k}] <{ggc.tag}> attribs={ggc.attrib} text={repr(ggc.text)}")
            if j > 3:
                print(f"          ... ({len(list(child))} total children of <{child.tag}>)")
                break
        if i > 8:
            print(f"    ... ({len(list(table))} total direct children of <{table.tag}>)")
            break

    # Now find first pcsRow
    pcsrow = table.find("pcsRow") or table.find("PCSRow")
    if pcsrow is None:
        print(f"\nNo <pcsRow> found inside <{table.tag}>")
        print(f"Child tags: {list({c.tag for c in table})}")
    else:
        print(f"\n--- First <{pcsrow.tag}> inside table ---")
        for i, child in enumerate(pcsrow):
            print(f"    [{i}] <{child.tag}> attribs={child.attrib}")
            for j, grandchild in enumerate(child):
                print(f"          [{j}] <{grandchild.tag}> attribs={grandchild.attrib} text={repr(grandchild.text)}")
            if i > 5:
                print(f"    ... ({len(list(pcsrow))} total)")
                break

    # Try to extract one working code
    print("\n--- Attempting one code extraction ---")
    axes = {}
    for axis in table.findall("axis"):
        pos = axis.get("position", axis.get("pos", "?"))
        codes = [(c.get("tag","?"), (c.find("description") or c).text or "") 
                 for c in axis.findall("code")]
        axes[pos] = codes
        print(f"  table axis pos={pos}: {codes[:2]} ({'...' if len(codes)>2 else ''})")

    first_row = table.find("pcsRow") or table.find("PCSRow")
    if first_row:
        for axis in first_row.findall("axis"):
            pos = axis.get("position", axis.get("pos", "?"))
            codes = [(c.get("tag","?"), (c.find("description") or c).text or "")
                     for c in axis.findall("code")]
            axes[pos] = codes
            print(f"  row   axis pos={pos}: {codes[:2]}")
        print(f"  Positions collected: {sorted(axes.keys())}")
        if set(axes.keys()) == {'1','2','3','4','5','6','7'}:
            from itertools import product as iprod
            combo = [axes[str(p)][0] for p in range(1,8)]
            code = "".join(ch for ch,_ in combo)
            print(f"  Sample code: {code}  (first value of each axis)")
        else:
            print(f"  Missing positions: {set('1234567') - set(axes.keys())}")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "reference_data/icd10pcs_tables_2027.xml"
    probe(path)
